function enableFields(form){
    if ( form.getFormMode() != 'ADD' ){  
        form.setEnabled("nome",false);
        form.setEnabled("cpf",false);
        form.setEnabled("rg",false);
        form.setEnabled("nascimento",false);
        form.setEnabled("estadocivil",false);
        form.setEnabled("escolaridade",false);
        form.setEnabled("profissao",false);
        form.setEnabled("cep",false);
        form.setEnabled("logradouro",false);
        form.setEnabled("num",false);
        form.setEnabled("bairro",false);
        form.setEnabled("cidade",false);
        form.setEnabled("estado",false);

    }
 }
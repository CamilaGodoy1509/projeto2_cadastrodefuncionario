function validateForm(form){
    var msg = ""
    
    // PAINEL DADOS PESSOAIS
    if (form.getValue("nome") == "") {
        msg += "Campo Nome não foi preenchido"
    }


    if (form.getValue("cpf") == "") {
        msg += "Campo CPF não foi preenchido"
    }

    if (form.getValue("rg") == "") {
        msg += "Campo RG não foi preenchido"
    }

    if (form.getValue("nascimento") == "") {
        msg += "Campo Data de Nascimento não foi preenchido"
    }

    if (form.getValue("estadocivil") == "") {
        msg += "Campo Estado Civil não foi preenchido"
    }

    if (form.getValue("escolaridade") == "") {
        msg += "Campo Escolaridade não foi preenchido"
    }

    if (form.getValue("profissao") == "") {
        msg += "Campo Profissão não foi preenchido"
    }

    //PAINEL ENDEREÇO
    if (form.getValue("cep") == "") {
        msg += "Campo CEP não foi preenchido"
    }

    if (form.getValue("logradouro") == "") {
        msg += "Campo Logradouro não foi preenchido"
    }

    if (form.getValue("num") == "") {
        msg += "Campo Número não foi preenchido"
    }

    if (form.getValue("bairro") == "") {
        msg += "Campo Bairro não foi preenchido"
    }

    if (form.getValue("cidade") == "") {
        msg += "Campo Cidade não foi preenchido"
    }

    if (form.getValue("estado") == "") {
        msg += "Campo Estado não foi preenchido"
    }

    if (msg != "") {
        throw msg
    }
}